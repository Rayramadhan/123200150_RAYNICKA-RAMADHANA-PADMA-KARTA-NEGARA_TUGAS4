package login.o;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
public class home extends JFrame implements ActionListener {
    
    public home() {
    }
   
    public void setBounds() {
    }
 
    public void addComponents() {
 
    }
  
    public void addActionListener() {
 
    }
 
    @Override
    public void actionPerformed(ActionEvent e) {
 
    }
 
    public static void main(String[] args) {
      
        qqqq frame = new qqqq();
        frame.setTitle("EHE");
        frame.setVisible(true);
        frame.setBounds(250, 250, 370, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
 
    }
}