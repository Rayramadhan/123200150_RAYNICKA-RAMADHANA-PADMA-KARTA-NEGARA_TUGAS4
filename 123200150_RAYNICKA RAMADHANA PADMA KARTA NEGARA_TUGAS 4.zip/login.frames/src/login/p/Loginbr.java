package login.p;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import login.s.jdbc;



public class Loginbr {

    Connection con = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
    int st;

    public jdbc checkLogin(String uname) {
        jdbc tugasjdbc = new jdbc();
        con = konek.getConnection();
        try {
            String query = "select * from tugasjdbc where  mailid=?";
            ps = con.prepareStatement(query);
            ps.setString(1, uname);
            rs = ps.executeQuery();
            while (rs.next()) {
               tugasjdbc.setId(rs.getLong("id"));
                tugasjdbc.setName(rs.getString("name"));
                tugasjdbc.setMailId(rs.getString("mailid"));
                tugasjdbc.setPassword(rs.getString("password"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return tugasjdbc;
    }
}
