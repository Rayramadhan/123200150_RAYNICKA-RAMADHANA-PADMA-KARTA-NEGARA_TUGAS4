CREATE TABLE tugasjdbc
  (
     id        BIGINT(100) UNSIGNED NOT NULL auto_increment,
     name      VARCHAR(100),
     mobile_no VARCHAR(12),
     mailid    VARCHAR(100),
     password  VARCHAR(100),
     PRIMARY KEY (id),
     UNIQUE KEY (mobile_no)
  )
engine=innodb
DEFAULT charset=utf8; 